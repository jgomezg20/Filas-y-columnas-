from pasajero import Pasajero
from mi_pila import MiPila
from mi_cola import MiCola

pila = MiPila(10)
cola = MiCola(10)


# ------------------------- funciones de apoyo -------------------------
def leer_entero(mensaje):
    while True:
        try:
            return int(input(mensaje))
        except ValueError:
            print("  Debe ser un número entero.")


def leer_pasajero():
    numero = leer_entero("  N.º de pasajero: ")
    nombre = input("  Nombre: ").strip()
    cedula = input("  Cédula: ").strip()
    edad = leer_entero("  Edad: ")
    fecha = input("  Fecha de vuelo (AAAA-MM-DD): ").strip()
    destino = input("  Destino: ").strip()
    asiento = input("  Asiento: ").strip().upper()
    return Pasajero(numero, nombre, cedula, edad, fecha, destino, asiento)


def datos_prueba():
    """Los 5 pasajeros de prueba en ORDEN DE LLEGADA (Diana llega primero, Elena última)."""
    return [
        Pasajero(1005, "Diana", "0923456789", 22, "2026-11-15", "Quito",  "12A"),
        Pasajero(1002, "Ana",   "0912345678", 28, "2026-11-15", "Lima",   "03C"),
        Pasajero(1009, "Luis",  "0987654321", 35, "2026-11-20", "Bogotá", "18F"),
        Pasajero(1004, "Beto",  "0934567890", 16, "2026-11-20", "Quito",  "07B"),
        Pasajero(1001, "Elena", "0901234567", 41, "2026-11-22", "Lima",   "01A"),
    ]


def mostrar_opciones(titulo, entrar, salir, ver):
    print(f"\n========== {titulo} ==========")
    print(f" 1. {entrar:<12}  2. Listar          3. {salir}")
    print(f" 4. {ver:<12}  5. Buscar          6. Modificar")
    print(" 7. Eliminar por número         8. Copiar")
    print(" 9. Longitud / ¿vacía?")
    print(" C. Cargar datos de prueba      0. Volver")


# Las opciones 5 a 9 son idénticas en pila y cola: se comparten (leer → llamar → mostrar)
def opcion_buscar(estructura):
    numero = leer_entero("  N.º de pasajero a buscar: ")          # 1. LEER
    pos = estructura.buscar(numero)                               # 2. LLAMAR
    if pos == -1:                                                 # 3. MOSTRAR
        print("  No existe")
    else:
        print(f"  Encontrado en [{pos}]: {estructura.datos[pos].nombre}")


def opcion_modificar(estructura):
    numero = leer_entero("  N.º de pasajero a modificar: ")
    destino = input("  Nuevo destino: ").strip()
    asiento = input("  Nuevo asiento: ").strip().upper()
    if estructura.modificar(numero, destino, asiento):
        print("  ✓ Pasajero modificado")
    else:
        print("  No existe")


def opcion_eliminar(estructura):
    numero = leer_entero("  N.º de pasajero a eliminar: ")
    eliminado = estructura.eliminar_por_numero(numero)
    if eliminado is None:
        print("  No existe")
    else:
        print(f"  ✓ Eliminado: {eliminado.nombre}")


def opcion_copiar(estructura):
    copia = estructura.copiar()
    print("  ✓ Copia creada. Contenido de la copia:")
    copia.listar()


def opcion_longitud(estructura):
    print(f"  Longitud: {estructura.longitud()}")
    if estructura.esta_vacia():
        print("  Está vacía")
    else:
        print("  No está vacía")


# ---------------------- MENÚ 1 · PILA ----------------------
def menu_pila():
    while True:
        mostrar_opciones("MENÚ 1 · PILA (LIFO)", "Apilar", "Desapilar", "Ver tope")
        op = input("Opción: ").strip().upper()

        if op == "1":
            pasajero = leer_pasajero()
            if pila.apilar(pasajero):
                print("  ✓ Apilado: ahora es el tope")
        elif op == "2":
            pila.listar()
        elif op == "3":
            p = pila.desapilar()
            if p is None:
                print("  La pila está vacía")
            else:
                print(f"  Salió: {p.nombre}")
                nuevo = pila.ver_tope()
                if nuevo is None:
                    print("  La pila quedó vacía")
                else:
                    print(f"  Nuevo tope: {nuevo.nombre}")
        elif op == "4":
            p = pila.ver_tope()
            if p is None:
                print("  La pila está vacía")
            else:
                print(f"  Tope: {p.nombre} ({p.numero})")
        elif op == "5":
            opcion_buscar(pila)
        elif op == "6":
            opcion_modificar(pila)
        elif op == "7":
            opcion_eliminar(pila)
        elif op == "8":
            opcion_copiar(pila)
        elif op == "9":
            opcion_longitud(pila)
        elif op == "C":
            for p in datos_prueba():
                pila.apilar(p)
            print("  ✓ Datos de prueba apilados")
        elif op == "0":
            break
        else:
            print("  Opción no válida")


# ---------------------- MENÚ 2 · COLA ----------------------
def menu_cola():
    while True:
        mostrar_opciones("MENÚ 2 · COLA (FIFO)", "Encolar", "Desencolar", "Ver frente")
        op = input("Opción: ").strip().upper()

        if op == "1":
            pasajero = leer_pasajero()
            if cola.encolar(pasajero):
                print("  ✓ Encolado: está al final")
        elif op == "2":
            cola.listar()
        elif op == "3":
            p = cola.desencolar()
            if p is None:
                print("  La cola está vacía")
            else:
                print(f"  Salió: {p.nombre}")
                nuevo = cola.ver_frente()
                if nuevo is None:
                    print("  La cola quedó vacía")
                else:
                    print(f"  Nuevo frente: {nuevo.nombre}")
        elif op == "4":
            p = cola.ver_frente()
            if p is None:
                print("  La cola está vacía")
            else:
                print(f"  Frente: {p.nombre} ({p.numero})")
        elif op == "5":
            opcion_buscar(cola)
        elif op == "6":
            opcion_modificar(cola)
        elif op == "7":
            opcion_eliminar(cola)
        elif op == "8":
            opcion_copiar(cola)
        elif op == "9":
            opcion_longitud(cola)
        elif op == "C":
            for p in datos_prueba():
                cola.encolar(p)
            print("  ✓ Datos de prueba encolados")
        elif op == "0":
            break
        else:
            print("  Opción no válida")


# ---------------------- MENÚ PRINCIPAL ----------------------
def main():
    while True:
        print("\n===== TAREA PILAS Y COLAS · PASAJEROS ✈ =====")
        print("1. Menú 1 · Pila")
        print("2. Menú 2 · Cola")
        print("3. Salir")
        op = input("Opción: ").strip()
        if op == "1":
            menu_pila()
        elif op == "2":
            menu_cola()
        elif op == "3":
            print("¡Hasta pronto!")
            break
        else:
            print("Opción no válida")


if __name__ == "__main__":
    main()
